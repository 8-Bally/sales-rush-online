// Sales Rush multiplayer server: serves the game and runs rooms over WebSockets.
// All game rules live in public/engine.js, shared with the browser's practice mode.
const http = require('http');
const fs = require('fs');
const path = require('path');
const WebSocket = require('ws');
const { createHub } = require('./public/engine.js');

const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json' };

const server = http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent(req.url.split('?')[0]); } catch { res.writeHead(400); return res.end('Bad request'); }
  if (url === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  const full = path.normalize(path.join(PUBLIC, url === '/' ? 'index.html' : url));
  if (!full.startsWith(PUBLIC + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(full, (err, data) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(full)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});

const hub = createHub();
const wss = new WebSocket.Server({ server, maxPayload: 4096 });

wss.on('connection', ws => {
  const conn = hub.connect(msg => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg)); });
  let windowStart = Date.now(), count = 0;
  ws.on('message', raw => {
    const t = Date.now();
    if (t - windowStart > 1000) { windowStart = t; count = 0; }
    if (++count > 40) return; // ignore floods
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    if (msg && typeof msg.type === 'string') hub.receive(conn, msg);
  });
  ws.on('close', () => hub.disconnect(conn));
  ws.on('error', () => {});
});

setInterval(() => hub.tick(), 100);

server.listen(PORT, () => console.log(`Sales Rush running on http://localhost:${PORT}`));
