// Sales Rush game engine: Open Floor rules plus a message hub.
// The same file runs on the Node server (real multiplayer) and in the browser
// (practice mode against CPU reps), so both play by exactly the same rules.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./content.js'));
  else root.SREngine = factory(root.SRContent);
})(typeof self !== 'undefined' ? self : this, function (CONTENT) {
  'use strict';

  const CFG = {
    ROUND_MS: 180000,        // 3:00 round
    DECIDE_MS: 24000,        // time to answer each buyer message
    FEEDBACK_MS: 1300,       // pause after a strong reply before the next message
    COOLDOWN_MS: 2000,       // pause after fumbling before you can claim again
    REFILL_MS: 1200,         // delay before a new lead lands on the floor
    QUOTA: 25000,
    MAX_PLAYERS: 8,
    WHALE_AT: [60000, 120000], // elapsed time when whale leads drop
    STEAL_MULT: 1.2,         // a fumbled deal is worth 20% more to whoever steals it
    STEAL_BONUS: 500,
    QUOTA_BONUS: 2500
  };
  const COLORS = ['#ffd23f', '#3ee0a1', '#ff8fb1', '#7fb2ff', '#ff9f43', '#c4a1ff', '#5ce1e6', '#f2f0ff'];
  // Reps a player can pick (drawn in art.js): six people, then six mascots.
  const CHARS = ['amara', 'marcus', 'mei', 'diego', 'grace', 'riley', 'mug', 'cat', 'bot', 'cactus', 'toast', 'owl'];
  const BOT_NAMES = ['Rivera', 'Okonkwo', 'Lindqvist', 'Tanaka', 'Moreau', 'Abebe', 'Kowalski'];
  const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const fmt = n => '$' + Math.round(n).toLocaleString('en-US');
  function cleanName(s) { return String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 16) || 'Rep'; }
  function shuffle(arr, rnd) { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = a[i]; a[i] = a[j]; a[j] = t; } return a; }

  /* ---------- room and players ---------- */

  function makeRoom(code, rnd) {
    return { code, rnd, phase: 'lobby', players: [], hostId: null, nextPid: 1, leads: [], nextLeadId: 1, deck: [],
      feed: [], feedSeq: 0, startedAt: 0, endsAt: 0, whales: 0, refillAt: 0, results: null, firstQuota: null,
      dirty: true, lastBroadcast: 0, emptySince: 0 };
  }

  function resetStats(p) {
    Object.assign(p, { score: 0, revenue: 0, deals: 0, steals: 0, fumbles: 0, streak: 0, bestStreak: 0, right: 0, asked: 0,
      quotaHit: false, active: null, last: null, cooldownUntil: 0, nextActAt: 0 });
  }

  function addPlayer(room, opts) {
    const used = new Set(room.players.map(p => p.color));
    const p = { id: 'p' + room.nextPid++, name: cleanName(opts.name), token: opts.token || '', isBot: !!opts.isBot,
      char: CHARS.includes(opts.char) ? opts.char : CHARS[Math.floor(room.rnd() * CHARS.length)],
      color: COLORS.find(c => !used.has(c)) || COLORS[0], skill: opts.skill || 0, connected: true, conn: null };
    resetStats(p);
    room.players.push(p);
    if (!room.hostId && !p.isBot) room.hostId = p.id;
    room.dirty = true;
    return p;
  }

  function removePlayer(room, pid) {
    const p = room.players.find(x => x.id === pid);
    if (!p) return;
    if (p.active) { const lead = findLead(room, p.active.leadId); if (lead) lead.claimedBy = null; }
    room.players = room.players.filter(x => x.id !== pid);
    if (room.hostId === pid) { const next = room.players.find(x => !x.isBot && x.connected); room.hostId = next ? next.id : null; }
    room.dirty = true;
  }

  function addBot(room) {
    const taken = new Set(room.players.map(p => p.name));
    const name = BOT_NAMES.find(n => !taken.has(n)) || 'Rep ' + room.nextPid;
    return addPlayer(room, { name, isBot: true, skill: 0.45 + room.rnd() * 0.15 });
  }

  function log(room, now, text, kind, pid) {
    const t = room.startedAt ? Math.max(0, now - room.startedAt) : 0;
    room.feed.push({ seq: ++room.feedSeq, t, text, kind: kind || 'info', pid: pid || null });
    if (room.feed.length > 30) room.feed.shift();
  }

  /* ---------- the floor ---------- */

  const findLead = (room, id) => room.leads.find(l => l.id === id);
  const floorSize = room => clamp(room.players.length + 2, 4, 8);
  const openCount = room => room.leads.filter(l => !l.claimedBy).length;

  function spawn(room, src, whale, now) {
    const swing = whale ? 1 : 0.85 + room.rnd() * 0.35;
    const lead = { id: 'L' + room.nextLeadId++, src, qs: src.qs.map(slot => Array.isArray(slot) ? slot[Math.floor(room.rnd() * slot.length)] : slot), co: src.co, who: src.who, role: src.role, char: src.char,
      value: Math.round(src.value * swing / 100) * 100, whale: !!whale, steal: false, fumbledBy: null,
      stage: 0, claimedBy: null, born: now };
    room.leads.push(lead);
    room.dirty = true;
    return lead;
  }

  function drawLead(room, now) {
    const onFloor = new Set(room.leads.map(l => l.co));
    for (let tries = 0; tries < CONTENT.LEADS.length * 2; tries++) {
      if (!room.deck.length) room.deck = shuffle(CONTENT.LEADS.map((_, i) => i), room.rnd);
      const src = CONTENT.LEADS[room.deck.pop()];
      if (!onFloor.has(src.co)) return spawn(room, src, false, now);
    }
    return null;
  }

  function refill(room, now) {
    while (openCount(room) < floorSize(room)) { if (!drawLead(room, now)) break; }
  }

  /* ---------- round flow ---------- */

  function start(room, now) {
    room.players.forEach(resetStats);
    room.leads = []; room.deck = []; room.feed = []; room.results = null; room.firstQuota = null;
    room.phase = 'playing'; room.startedAt = now; room.endsAt = now + CFG.ROUND_MS; room.whales = 0;
    refill(room, now);
    room.players.forEach(p => { if (p.isBot) p.nextActAt = now + 1500 + room.rnd() * 2500; });
    log(room, now, 'The floor is open. Claim a lead!', 'info');
    room.dirty = true;
  }

  function startQuestion(room, p, now) {
    const lead = findLead(room, p.active.leadId);
    p.active.order = shuffle([0, 1, 2, 3], room.rnd);
    p.active.phase = 'question';
    p.active.deadline = now + CFG.DECIDE_MS;
    p.active.feedback = null;
    p.active.stage = lead.stage;
  }

  function claim(room, p, leadId, now) {
    if (room.phase !== 'playing' || p.active || now < p.cooldownUntil) return 'busy';
    const lead = findLead(room, leadId);
    if (!lead) return 'gone';
    if (lead.claimedBy) return 'taken';
    if (lead.fumbledBy === p.id) return 'own-fumble';
    lead.claimedBy = p.id;
    p.active = { leadId: lead.id };
    p.last = null;
    startQuestion(room, p, now);
    if (lead.steal) {
      const victim = room.players.find(x => x.id === lead.fumbledBy);
      log(room, now, p.name + ' swooped on ' + (victim ? victim.name + "'s fumble" : 'a fumble') + ': ' + lead.co + '.', 'swoop', p.id);
    } else if (lead.whale) {
      log(room, now, p.name + ' grabbed the whale: ' + lead.co + '!', 'swoop', p.id);
    }
    room.refillAt = now + CFG.REFILL_MS;
    room.dirty = true;
    return 'ok';
  }

  const mult = streak => Math.min(4, 1 + Math.floor(streak / 2));

  function answer(room, p, choice, now) {
    const act = p.active;
    if (room.phase !== 'playing' || !act || act.phase !== 'question') return;
    if (!(choice === -1 || (Number.isInteger(choice) && choice >= 0 && choice < 4))) return;
    const lead = findLead(room, act.leadId);
    const q = lead.qs[lead.stage];
    const correctIdx = act.order.indexOf(0);
    const correct = choice >= 0 && act.order[choice] === 0;
    p.asked++;
    if (correct) {
      p.right++; p.streak++; p.bestStreak = Math.max(p.bestStreak, p.streak);
      const fast = act.deadline - now > CFG.DECIDE_MS / 2;
      const pts = 100 * mult(p.streak) + (fast ? 250 : 0);
      p.score += pts;
      lead.stage++;
      act.phase = 'feedback';
      act.nextAt = now + CFG.FEEDBACK_MS;
      act.feedback = { correct: true, chosen: choice, correctIdx, note: q.note, tone: q.tone, pts, fast, mult: mult(p.streak) };
    } else {
      p.streak = 0; p.fumbles++;
      p.last = { kind: 'fumble', at: now, co: lead.co, who: lead.who, char: lead.char, question: q.q,
        options: act.order.map(i => q.a[i]), chosen: choice, correctIdx, note: q.note, tone: q.tone, timeout: choice < 0 };
      if (!lead.steal) lead.value = Math.round(lead.value * CFG.STEAL_MULT / 100) * 100;
      lead.claimedBy = null; lead.fumbledBy = p.id; lead.steal = true;
      p.active = null;
      p.cooldownUntil = now + CFG.COOLDOWN_MS;
      log(room, now, p.name + (choice < 0 ? ' froze on ' : ' fumbled ') + lead.co + '. Up for grabs at ' + fmt(lead.value) + '!', 'steal', p.id);
    }
    room.dirty = true;
  }

  function close(room, p, now) {
    const lead = findLead(room, p.active.leadId);
    const stolen = lead.steal && lead.fumbledBy !== p.id;
    let pts = 500 + Math.round(lead.value * 0.18) + (stolen ? CFG.STEAL_BONUS : 0);
    p.revenue += lead.value; p.deals++;
    if (stolen) p.steals++;
    let quota = false;
    if (!p.quotaHit && p.revenue >= CFG.QUOTA) {
      p.quotaHit = true; quota = true; pts += CFG.QUOTA_BONUS;
      if (!room.firstQuota) room.firstQuota = p.id;
    }
    p.score += pts;
    p.last = { kind: 'closed', at: now, co: lead.co, who: lead.who, char: lead.char, value: lead.value, pts, stolen, whale: lead.whale, quota };
    room.leads = room.leads.filter(l => l !== lead);
    p.active = null;
    log(room, now, p.name + (stolen ? ' stole and closed ' : ' closed ') + lead.co + ' for ' + fmt(lead.value) + '.', lead.whale ? 'whale-close' : 'close', p.id);
    if (quota) log(room, now, p.name + ' hit the $25K quota!', 'quota', p.id);
    room.refillAt = now + CFG.REFILL_MS;
    room.dirty = true;
  }

  function end(room, now) {
    room.phase = 'ended';
    room.players.forEach(p => {
      if (p.active) { const lead = findLead(room, p.active.leadId); if (lead) lead.claimedBy = null; }
      p.active = null;
    });
    room.results = room.players.slice().sort((a, b) => b.score - a.score).map(p => p.id);
    log(room, now, 'Time! The floor is closed.', 'info');
    room.dirty = true;
  }

  function botStep(room, p, now) {
    if (now < p.nextActAt) return;
    const think = () => 4500 + room.rnd() * 3300;
    if (!p.active) {
      if (now < p.cooldownUntil) return;
      const open = room.leads.filter(l => !l.claimedBy && l.fumbledBy !== p.id);
      if (!open.length) { p.nextActAt = now + 1000; return; }
      const juicy = open.filter(l => l.whale || l.steal);
      const pick = juicy.length && room.rnd() < 0.35 ? juicy[Math.floor(room.rnd() * juicy.length)] : open[Math.floor(room.rnd() * open.length)];
      claim(room, p, pick.id, now);
      p.nextActAt = now + think();
    } else if (p.active.phase === 'question') {
      const right = p.active.order.indexOf(0);
      let choice = right;
      if (room.rnd() > p.skill) { const wrong = [0, 1, 2, 3].filter(i => i !== right); choice = wrong[Math.floor(room.rnd() * 3)]; }
      answer(room, p, choice, now);
      p.nextActAt = now + (p.active ? CFG.FEEDBACK_MS + think() : 2500 + room.rnd() * 3000);
    }
  }

  function tick(room, now) {
    if (room.phase !== 'playing') return;
    for (const p of room.players) {
      const act = p.active;
      if (act && act.phase === 'question' && now >= act.deadline) answer(room, p, -1, now);
      else if (act && act.phase === 'feedback' && now >= act.nextAt) {
        const lead = findLead(room, act.leadId);
        if (lead.stage >= 3) close(room, p, now); else startQuestion(room, p, now);
        room.dirty = true;
      }
    }
    while (room.whales < CFG.WHALE_AT.length && now - room.startedAt >= CFG.WHALE_AT[room.whales]) {
      const src = CONTENT.WHALES[room.whales % CONTENT.WHALES.length];
      room.whales++;
      spawn(room, src, true, now);
      log(room, now, 'WHALE ALERT: ' + src.co + ' (' + fmt(src.value) + ') just hit the floor!', 'whale');
    }
    if (now >= room.refillAt && openCount(room) < floorSize(room)) refill(room, now);
    for (const p of room.players) if (p.isBot) botStep(room, p, now);
    if (now >= room.endsAt) end(room, now);
  }

  /* ---------- what each player is allowed to see ---------- */

  function view(room, pid, now) {
    const me = room.players.find(p => p.id === pid);
    const nameOf = id => { const p = room.players.find(x => x.id === id); return p ? p.name : ''; };
    const pub = p => ({ id: p.id, name: p.name, color: p.color, char: p.char, isBot: p.isBot, connected: p.connected,
      score: p.score, revenue: p.revenue, deals: p.deals, steals: p.steals, fumbles: p.fumbles, quotaHit: p.quotaHit,
      bestStreak: p.bestStreak, right: p.right, asked: p.asked, busy: !!p.active });
    let active = null;
    if (me && me.active) {
      const lead = findLead(room, me.active.leadId);
      const q = lead.qs[me.active.stage];
      active = { leadId: lead.id, co: lead.co, who: lead.who, role: lead.role, char: lead.char, value: lead.value,
        whale: lead.whale, steal: lead.steal && lead.fumbledBy !== me.id, stage: me.active.stage, question: q.q,
        options: me.active.order.map(i => q.a[i]), phase: me.active.phase, deadline: me.active.deadline, feedback: me.active.feedback };
    }
    return {
      now, code: room.code, phase: room.phase, you: pid, hostId: room.hostId,
      cfg: { ROUND_MS: CFG.ROUND_MS, DECIDE_MS: CFG.DECIDE_MS, QUOTA: CFG.QUOTA, MAX_PLAYERS: CFG.MAX_PLAYERS },
      startedAt: room.startedAt, endsAt: room.endsAt, firstQuota: room.firstQuota,
      players: room.players.map(pub),
      floor: room.leads.map(l => ({ id: l.id, co: l.co, who: l.who, role: l.role, char: l.char, value: l.value, whale: l.whale,
        steal: l.steal, fumbledBy: l.fumbledBy, fumbledByName: l.fumbledBy ? nameOf(l.fumbledBy) : '',
        stage: l.stage, claimedBy: l.claimedBy, claimedByName: l.claimedBy ? nameOf(l.claimedBy) : '' })),
      me: me ? { streak: me.streak, mult: mult(me.streak), cooldownUntil: me.cooldownUntil, last: me.last, active } : null,
      feed: room.feed.slice(-10),
      results: room.results
    };
  }

  /* ---------- hub: rooms, connections, messages ---------- */

  function createHub(opts) {
    opts = opts || {};
    const now = opts.now || (() => Date.now());
    const rnd = opts.random || Math.random;
    const rooms = new Map();
    let nextConn = 1;

    function newCode() {
      let c;
      do { c = ''; for (let i = 0; i < 4; i++) c += CODE_CHARS[Math.floor(rnd() * CODE_CHARS.length)]; } while (rooms.has(c));
      return c;
    }
    function broadcast(room) {
      const t = now();
      for (const p of room.players) if (p.conn) p.conn.send({ type: 'state', state: view(room, p.id, t) });
      room.dirty = false; room.lastBroadcast = t;
    }
    const fail = (conn, message) => conn.send({ type: 'error', message });
    const roomOf = conn => conn.code ? rooms.get(conn.code) : null;
    const playerOf = (conn, room) => room && room.players.find(p => p.id === conn.pid && p.conn === conn);

    function leave(conn) {
      const room = roomOf(conn);
      if (room) { const p = playerOf(conn, room); if (p) removePlayer(room, p.id); broadcast(room); }
      conn.code = null; conn.pid = null;
    }

    function join(conn, room, msg) {
      const token = String(msg.token || '').slice(0, 64);
      let p = token && room.players.find(x => !x.isBot && x.token === token);
      if (p) {
        if (p.conn && p.conn !== conn) { p.conn.code = null; p.conn.pid = null; }
        p.connected = true; p.name = cleanName(msg.name || p.name);
        if (CHARS.includes(msg.char)) p.char = msg.char;
      } else {
        if (room.players.length >= CFG.MAX_PLAYERS) return fail(conn, 'Room ' + room.code + ' is full (8 players). Create a new room instead.');
        p = addPlayer(room, { name: msg.name, token, char: msg.char });
        if (room.phase === 'playing') log(room, now(), p.name + ' joined mid-round.', 'info');
      }
      p.conn = conn; conn.code = room.code; conn.pid = p.id;
      if (!room.hostId || !room.players.some(x => x.id === room.hostId && x.connected)) room.hostId = p.id;
      conn.send({ type: 'joined', code: room.code, you: p.id });
      broadcast(room);
    }

    function receive(conn, msg) {
      if (!msg || typeof msg.type !== 'string') return;
      const t = now();
      if (msg.type === 'rooms') {
        const list = [...rooms.values()]
          .filter(r => r.phase !== 'playing' && !r.practice && r.players.some(p => !p.isBot && p.connected) && r.players.length < CFG.MAX_PLAYERS)
          .slice(0, 12).map(r => ({ code: r.code, host: (r.players.find(p => p.id === r.hostId) || {}).name || '', players: r.players.length }));
        return conn.send({ type: 'rooms', rooms: list });
      }
      if (msg.type === 'create') {
        leave(conn);
        const room = makeRoom(newCode(), rnd);
        room.practice = !!msg.practice;
        rooms.set(room.code, room);
        join(conn, room, msg);
        if (room.practice) { for (let i = 0; i < 3; i++) addBot(room); start(room, t); broadcast(room); }
        return;
      }
      if (msg.type === 'join') {
        const code = String(msg.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
        const room = rooms.get(code);
        if (!room) return fail(conn, 'No room with code ' + (code || '(blank)') + '. Check the code, or create a new room.');
        if (conn.code && conn.code !== code) leave(conn);
        return join(conn, room, msg);
      }
      if (msg.type === 'leave') return leave(conn);

      const room = roomOf(conn), p = playerOf(conn, room);
      if (!room || !p) return fail(conn, 'You are not in a room yet.');
      const isHost = room.hostId === p.id;
      switch (msg.type) {
        case 'addBot':
          if (!isHost || room.phase === 'playing') return;
          if (room.players.length >= CFG.MAX_PLAYERS) return fail(conn, 'The room is full.');
          addBot(room); break;
        case 'removeBot': {
          const b = room.players.find(x => x.id === msg.id && x.isBot);
          if (isHost && b && room.phase !== 'playing') removePlayer(room, b.id);
          break;
        }
        case 'start':
          if (!isHost || room.phase === 'playing') return;
          if (room.players.length < 2) return fail(conn, 'You need at least 2 reps. Invite a friend or add a CPU rep.');
          start(room, t); break;
        case 'lobby':
          if (isHost && room.phase === 'ended') { room.phase = 'lobby'; room.dirty = true; }
          break;
        case 'claim': {
          const r = claim(room, p, String(msg.id || ''), t);
          if (r === 'taken') fail(conn, 'Too slow! Someone else claimed that lead.');
          else if (r === 'own-fumble') fail(conn, "You fumbled that one. Let someone else take a swing.");
          break;
        }
        case 'answer':
          answer(room, p, Number(msg.choice), t); break;
        default: return;
      }
      broadcast(room);
    }

    function disconnect(conn) {
      const room = roomOf(conn), p = playerOf(conn, room);
      if (!p) return;
      p.conn = null; p.connected = false;
      if (room.phase === 'lobby') removePlayer(room, p.id);
      else if (room.hostId === p.id) { const next = room.players.find(x => !x.isBot && x.connected); if (next) room.hostId = next.id; }
      room.dirty = true;
      broadcast(room);
    }

    function tickAll() {
      const t = now();
      for (const room of rooms.values()) {
        tick(room, t);
        const humans = room.players.some(p => !p.isBot && p.connected);
        if (!humans) {
          if (!room.emptySince) room.emptySince = t;
          else if (t - room.emptySince > 60000) { rooms.delete(room.code); continue; }
        } else room.emptySince = 0;
        if (room.dirty || t - room.lastBroadcast >= 1000) broadcast(room);
      }
    }

    function connect(send) { return { id: 'c' + nextConn++, send, code: null, pid: null }; }

    return { connect, receive, disconnect, tick: tickAll, rooms };
  }

  return { CFG, CHARS, createHub, fmt };
});
