// Sales Rush audio: an original chiptune loop and sound effects, synthesized
// live with Web Audio (no audio files, nothing to license).
(function (root) {
  'use strict';
  let ctx = null, master = null, musicBus = null, sfxBus = null, noise = null;
  let musicOn = true, sfxOn = true, playing = false, timer = 0, step = 0, nextTime = 0, bpm = 118, hype = false;
  try { musicOn = localStorage.getItem('sr-music') !== 'off'; sfxOn = localStorage.getItem('sr-sfx') !== 'off'; } catch (e) {}

  function init() {
    if (ctx) return true;
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.8; master.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = musicOn ? 0.32 : 0; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = sfxOn ? 0.7 : 0; sfxBus.connect(master);
    noise = ctx.createBuffer(1, ctx.sampleRate * 0.5, ctx.sampleRate);
    const d = noise.getChannelData(0); for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    return true;
  }

  function note(bus, freq, t, dur, type, vol, slideTo) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'square'; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g).connect(bus); o.start(t); o.stop(t + dur + 0.02);
  }
  function hit(bus, t, dur, vol, filterType, freq) {
    const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = noise; f.type = filterType; f.frequency.value = freq;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f).connect(g).connect(bus); s.start(t); s.stop(t + dur + 0.02);
  }

  // i - VI - III - VII in C minor: punchy, a little sneaky, very "sales floor"
  const hz = n => 440 * Math.pow(2, (n - 69) / 12);
  const BASS = [36, 32, 39, 34];
  const ARP = [[60, 63, 67, 72], [56, 60, 63, 68], [63, 67, 70, 75], [58, 62, 65, 70]];
  const LEAD = [72, -1, 75, 74, -1, 72, 70, -1, 67, -1, 70, 72, -1, -1, 75, -1];

  function schedule() {
    const spb = 60 / bpm / 4; // one 16th note
    while (nextTime < ctx.currentTime + 0.15) {
      const t = nextTime, bar = Math.floor(step / 16) % 4, s = step % 16;
      if (s % 4 === 0) note(musicBus, 140, t, 0.14, 'sine', 0.9, 45);
      if (s === 4 || s === 12) hit(musicBus, t, 0.12, 0.35, 'bandpass', 1800);
      if (s % 2 === 1) hit(musicBus, t, 0.03, 0.18, 'highpass', 7000);
      if ([0, 3, 6, 8, 11, 14].includes(s)) note(musicBus, hz(BASS[bar]), t, spb * 1.8, 'triangle', 0.5);
      if (hype || s % 2 === 0) note(musicBus, hz(ARP[bar][s % 4]), t, spb * 0.9, 'square', 0.07);
      if (hype && LEAD[s] > 0 && bar % 2 === 1) note(musicBus, hz(LEAD[s]), t, spb * 1.6, 'sawtooth', 0.06);
      nextTime += spb; step++;
    }
  }

  const api = {
    get musicOn() { return musicOn; }, get sfxOn() { return sfxOn; },
    // Call from a click or key press: browsers only allow sound after the player interacts.
    unlock() { if (!init()) return; if (ctx.state === 'suspended') ctx.resume(); if (musicOn && !playing) api.startMusic(); },
    startMusic() {
      if (!init() || playing) return;
      playing = true; step = 0; nextTime = ctx.currentTime + 0.05;
      timer = setInterval(schedule, 25);
    },
    stopMusic() { playing = false; clearInterval(timer); },
    setHype(on) { hype = !!on; bpm = on ? 138 : 118; },
    setMusic(on) {
      musicOn = !!on; try { localStorage.setItem('sr-music', on ? 'on' : 'off'); } catch (e) {}
      if (ctx) musicBus.gain.value = on ? 0.32 : 0;
      if (on) api.unlock();
    },
    setSfx(on) {
      sfxOn = !!on; try { localStorage.setItem('sr-sfx', on ? 'on' : 'off'); } catch (e) {}
      if (ctx) sfxBus.gain.value = on ? 0.7 : 0;
    },
    play(name) {
      if (!ctx || !sfxOn) return;
      const t = ctx.currentTime + 0.01;
      switch (name) {
        case 'claim': note(sfxBus, 660, t, 0.06, 'square', 0.25); note(sfxBus, 880, t + 0.06, 0.08, 'square', 0.25); break;
        case 'good': note(sfxBus, 784, t, 0.07, 'square', 0.25); note(sfxBus, 1175, t + 0.07, 0.12, 'square', 0.25); break;
        case 'bad': note(sfxBus, 220, t, 0.28, 'sawtooth', 0.3, 110); break;
        case 'close':
          [523, 659, 784, 1047].forEach((f, i) => note(sfxBus, f, t + i * 0.07, 0.14, 'square', 0.25));
          hit(sfxBus, t + 0.3, 0.25, 0.5, 'highpass', 5000); note(sfxBus, 2093, t + 0.3, 0.3, 'triangle', 0.2); break;
        case 'steal': note(sfxBus, 1319, t, 0.08, 'square', 0.18); note(sfxBus, 1319, t + 0.12, 0.08, 'square', 0.18); break;
        case 'whale': note(sfxBus, 98, t, 0.6, 'sawtooth', 0.35, 196); note(sfxBus, 147, t + 0.1, 0.6, 'square', 0.15, 294); break;
        case 'otherClose': note(sfxBus, 988, t, 0.05, 'triangle', 0.15); note(sfxBus, 1319, t + 0.05, 0.08, 'triangle', 0.15); break;
        case 'tick': note(sfxBus, 1400, t, 0.03, 'square', 0.12); break;
        case 'nope': note(sfxBus, 300, t, 0.08, 'square', 0.15); note(sfxBus, 240, t + 0.08, 0.1, 'square', 0.15); break;
        case 'end': [784, 659, 523, 392, 523].forEach((f, i) => note(sfxBus, f, t + i * 0.13, 0.22, 'triangle', 0.3)); break;
      }
    }
  };
  root.SRAudio = api;
})(typeof self !== 'undefined' ? self : this);
