// Sales Rush client: screens, rendering, input, sound. Talks to the game hub
// either over WebSocket (online rooms) or in-page (practice vs CPU reps).
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const E = window.SREngine, Art = window.SRArt, Audio = window.SRAudio;
  const fmt = E.fmt;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const store = {
    get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  const mmss = ms => { const s = Math.max(0, Math.ceil(ms / 1000)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };

  const S = {
    online: null, local: null, mode: null, serverUp: false, wasConnected: false,
    state: null, offset: 0, code: null,
    name: store.get('sr-name') || '', char: Art.REPS.includes(store.get('sr-char')) ? store.get('sr-char') : 'amara',
    token: store.get('sr-token') || (Math.random().toString(36).slice(2) + Date.now().toString(36)),
    deskKey: '', cards: new Map(), lastSeq: 0, lastLastAt: 0, answered: false, lastTickSec: -1, hype: false, screen: 'home'
  };
  store.set('sr-token', S.token);
  const srvNow = () => Date.now() + S.offset;
  const me = () => S.state && S.state.players.find(p => p.id === S.state.you);

  /* ---------- transports ---------- */

  function connectOnline() {
    if (window.SR_SERVER_URL === 'none') return setNet('down');
    // ?local runs rooms inside this page (one device, CPU reps only). Handy for testing without a server.
    if (new URLSearchParams(location.search).has('local')) {
      const hub = E.createHub();
      const conn = hub.connect(m => setTimeout(() => { if (S.mode === 'online' || m.type === 'rooms') handle(JSON.parse(JSON.stringify(m))); }, 0));
      setInterval(() => hub.tick(), 100);
      S.online = { send(m) { hub.receive(conn, JSON.parse(JSON.stringify(m))); }, open: true };
      return setTimeout(() => setNet('up'), 0);
    }
    let url = window.SR_SERVER_URL;
    if (!url) {
      if (!/^https?:$/.test(location.protocol)) return setNet('down');
      url = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
    }
    let ws, open = false;
    const queue = [];
    const t = {
      send(m) { if (open) ws.send(JSON.stringify(m)); else queue.push(m); },
      get open() { return open; }
    };
    function go() {
      try { ws = new WebSocket(url); } catch (e) { return setNet('down'); }
      ws.onopen = () => { open = true; setNet('up'); queue.splice(0).forEach(m => ws.send(JSON.stringify(m))); };
      ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } if (S.mode === 'online' || m.type === 'rooms') handle(m); };
      ws.onclose = () => { const was = open; open = false; setNet(was ? 'lost' : 'down'); setTimeout(go, was ? 1200 : 5000); };
      ws.onerror = () => {};
    }
    go();
    S.online = t;
  }

  function startLocal() {
    if (S.local) S.local.close();
    const hub = E.createHub();
    const conn = hub.connect(m => setTimeout(() => { if (S.mode === 'practice') handle(JSON.parse(JSON.stringify(m))); }, 0));
    const iv = setInterval(() => hub.tick(), 100);
    S.local = { send(m) { hub.receive(conn, JSON.parse(JSON.stringify(m))); }, close() { clearInterval(iv); } };
  }

  const send = m => { const t = S.mode === 'practice' ? S.local : S.online; if (t) t.send(m); };

  function setNet(status) {
    S.serverUp = status === 'up';
    const note = $('netNote');
    if (status === 'up') {
      note.textContent = 'Connected. Create a room or join one below.'; note.className = 'net-note';
      if (S.wasConnected && S.mode === 'online' && S.code) { send({ type: 'join', code: S.code, name: S.name, char: S.char, token: S.token }); toast('Reconnected.'); }
      S.wasConnected = true;
      send({ type: 'rooms' });
    } else if (status === 'lost') {
      if (S.mode === 'online' && S.code) toast('Connection lost. Reconnecting…', 'bad');
    } else {
      note.textContent = "Can't reach the multiplayer server from this page. Practice mode still works."; note.className = 'net-note warn';
    }
  }

  /* ---------- messages ---------- */

  function handle(m) {
    if (m.type === 'rooms') return renderRooms(m.rooms);
    if (m.type === 'error') { toast(m.message, 'bad'); Audio.play('nope'); return; }
    if (m.type === 'joined') {
      S.code = m.code; S.deskKey = ''; S.cards.clear(); $('floor').textContent = ''; S.lastSeq = 0; S.lastLastAt = 0;
      try { history.replaceState(null, '', location.pathname + (S.mode === 'online' ? '?room=' + m.code : '')); } catch (e) {}
      return;
    }
    if (m.type === 'state') {
      const first = !S.state || S.state.code !== m.state.code;
      S.state = m.state; S.offset = m.state.now - Date.now();
      if (first) S.lastSeq = m.state.feed.length ? m.state.feed[m.state.feed.length - 1].seq : 0;
      render();
    }
  }

  /* ---------- screens ---------- */

  function show(name) {
    if (S.screen === name) return;
    S.screen = name;
    ['home', 'room', 'play', 'results'].forEach(id => { $(id).hidden = id !== name; });
    $('bgCast').classList.toggle('dim', name === 'play');
    window.scrollTo(0, 0);
    if (name === 'home') { send({ type: 'rooms' }); }
  }

  function render() {
    const st = S.state;
    if (!st || !S.code) return show('home');
    if (st.phase === 'lobby') { show('room'); renderRoom(st); }
    else if (st.phase === 'playing') { show('play'); renderPlay(st); }
    else { show('results'); renderResults(st); }
    processFeed(st);
  }

  /* ---------- home ---------- */

  function buildHome() {
    $('logoMark').innerHTML = Art.logo(40);
    $('hudLogo').innerHTML = Art.logo(32);
    $('heroCast').innerHTML = ['jordan', 'maya', 'sam', 'priya', 'vic', 'mug'].map((k, i) => Art.char(k, { mood: i % 2 ? 'happy' : 'neutral' })).join('');
    const spots = [[3, 12], [88, 8], [6, 62], [92, 55], [45, 86], [70, 30], [20, 88], [80, 85]];
    $('bgCast').innerHTML = spots.map((s, i) => `<div class="floater" style="left:${s[0]}%;top:${s[1]}%;animation-delay:${-i * 1.3}s">${Art.char(['theo', 'cat', 'morgan', 'toast', 'rosa', 'bot', 'chris', 'owl'][i], { mood: ['happy', 'neutral', 'shock'][i % 3] })}</div>`).join('');
    $('charPick').innerHTML = Art.REPS.map(k => `<button type="button" role="radio" data-char="${k}" aria-checked="${k === S.char}" aria-label="${Art.NAMES[k]}">${Art.char(k, { mood: k === S.char ? 'happy' : 'neutral' })}${Art.NAMES[k]}</button>`).join('');
    $('nameInput').value = S.name;
    const qp = new URLSearchParams(location.search).get('room');
    if (qp) { $('codeInput').value = qp.toUpperCase().slice(0, 6); $('nameInput').focus(); }
  }

  $('charPick').addEventListener('click', e => {
    const b = e.target.closest('button[data-char]'); if (!b) return;
    S.char = b.dataset.char; store.set('sr-char', S.char);
    $('charPick').querySelectorAll('button').forEach(x => {
      const on = x.dataset.char === S.char;
      x.setAttribute('aria-checked', on);
      x.innerHTML = Art.char(x.dataset.char, { mood: on ? 'happy' : 'neutral' }) + Art.NAMES[x.dataset.char];
    });
    Audio.unlock(); Audio.play('claim');
  });

  function readName() {
    S.name = $('nameInput').value.trim().slice(0, 16);
    if (!S.name) { $('nameInput').focus(); toast('Pick a name first.', 'bad'); return false; }
    store.set('sr-name', S.name);
    Audio.unlock();
    return true;
  }
  $('createBtn').onclick = () => {
    if (!S.serverUp) return toast("Multiplayer needs the game server, which isn't running on this page. Try Practice mode.", 'bad');
    if (!readName()) return;
    S.mode = 'online'; send({ type: 'create', name: S.name, char: S.char, token: S.token }); };
  $('joinForm').addEventListener('submit', e => {
    e.preventDefault();
    const code = $('codeInput').value.trim().toUpperCase();
    if (!code) { $('codeInput').focus(); return toast('Enter the room code your friend shared.', 'bad'); }
    if (!S.serverUp) return toast("Multiplayer needs the game server, which isn't running on this page. Try Practice mode.", 'bad');
    if (!readName()) return;
    S.mode = 'online'; send({ type: 'join', code, name: S.name, char: S.char, token: S.token });
  });
  $('practiceBtn').onclick = () => {
    if (!readName()) return;
    S.mode = 'practice'; startLocal();
    send({ type: 'create', practice: true, name: S.name, char: S.char, token: S.token });
  };
  $('roomsList').addEventListener('click', e => {
    const b = e.target.closest('[data-code]'); if (!b) return;
    $('codeInput').value = b.dataset.code;
    $('joinForm').requestSubmit();
  });

  function renderRooms(list) {
    const box = $('roomsList');
    if (!list || !list.length) { box.innerHTML = '<div class="empty">No open rooms right now. Create one and send your friends the code.</div>'; return; }
    box.innerHTML = list.map(r => `<button class="room-item" type="button" data-code="${esc(r.code)}"><span><b>${esc(r.code)}</b><small>Host: ${esc(r.host || '—')}</small></span><span class="chip whale">${r.players}/8 · Join</span></button>`).join('');
  }
  setInterval(() => { if (S.screen === 'home' && S.serverUp) send({ type: 'rooms' }); }, 4000);

  /* ---------- waiting room ---------- */

  function renderRoom(st) {
    const host = st.hostId === st.you;
    $('roomCode').textContent = st.code;
    const practice = S.mode === 'practice';
    $('copyBtn').hidden = practice;
    $('inviteLink').textContent = practice ? 'Practice room: just you and the CPU reps.' : inviteUrl();
    $('rosterCount').textContent = st.players.length + ' / ' + st.cfg.MAX_PLAYERS;
    $('roster').innerHTML = st.players.map(p => `<li style="--pc:${p.color}">${Art.char(p.char, { color: p.color, mood: 'happy' })}
      <span class="who">${esc(p.name)}${p.id === st.you ? '<span class="tag you">You</span>' : ''}${p.id === st.hostId ? '<span class="tag">Host</span>' : ''}${p.isBot ? '<span class="tag">CPU</span>' : ''}
      <small>${p.isBot ? 'Computer rep' : p.connected ? 'Ready' : 'Reconnecting…'}</small></span>
      ${host && p.isBot ? `<button class="btn btn-link" data-remove="${p.id}" type="button" aria-label="Remove ${esc(p.name)}">Remove</button>` : '<span></span>'}</li>`).join('');
    $('hostControls').hidden = !host;
    $('waitHint').hidden = host;
    $('startBtn').disabled = st.players.length < 2;
    $('startBtn').textContent = st.players.length < 2 ? 'Need 2+ reps to start' : 'Start the round';
    $('addBotBtn').disabled = st.players.length >= st.cfg.MAX_PLAYERS;
  }
  const inviteUrl = () => location.origin + location.pathname + '?room=' + (S.code || '');
  $('roster').addEventListener('click', e => { const b = e.target.closest('[data-remove]'); if (b) send({ type: 'removeBot', id: b.dataset.remove }); });
  $('addBotBtn').onclick = () => { Audio.unlock(); send({ type: 'addBot' }); };
  $('startBtn').onclick = () => { Audio.unlock(); send({ type: 'start' }); };
  $('copyBtn').onclick = () => {
    const url = inviteUrl();
    const done = () => toast('Invite link copied. Send it to your crew!');
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, () => toast('Copy the link below the button.'));
    else toast('Copy the link below the button.');
  };
  function leave() {
    send({ type: 'leave' });
    if (S.local) { S.local.close(); S.local = null; }
    S.mode = null; S.code = null; S.state = null;
    try { history.replaceState(null, '', location.pathname); } catch (e) {}
    Audio.setHype(false);
    show('home');
  }
  $('leaveBtn').onclick = leave;
  $('leaveBtn2').onclick = leave;

  /* ---------- play ---------- */

  function renderPlay(st) {
    const my = me(); if (!my) return;
    $('hudRoom').textContent = S.mode === 'practice' ? 'PRACTICE' : 'ROOM ' + st.code;
    $('myScore').textContent = my.score.toLocaleString('en-US');
    $('myDeals').textContent = my.deals;
    $('myMult').textContent = '×' + st.me.mult;
    $('myRev').textContent = fmt(my.revenue) + ' / ' + fmt(st.cfg.QUOTA);
    $('myBar').style.width = Math.min(100, my.revenue / st.cfg.QUOTA * 100) + '%';
    renderDesk(st);
    renderFloor(st);
    renderStandings(st);
    renderFeed(st);
  }

  const STAGES = ['Qualify', 'Discover', 'Close'];

  function renderDesk(st) {
    const m = st.me, a = m.active, last = m.last;
    const key = a ? `q:${a.leadId}:${a.stage}:${a.phase}` : last ? `last:${last.kind}:${last.at}` : 'idle';
    if (key === S.deskKey) return;
    const prev = S.deskKey; S.deskKey = key;
    const desk = $('desk');
    const myChar = (me() || {}).char || 'mug', myColor = (me() || {}).color;

    if (last && last.at !== S.lastLastAt) {
      S.lastLastAt = last.at;
      if (last.kind === 'closed') { Audio.play('close'); confetti(); }
      else { Audio.play('bad'); desk.classList.remove('shake'); void desk.offsetWidth; desk.classList.add('shake'); }
    }

    if (a) {
      const fresh = a.phase === 'question' && !prev.startsWith('q:' + a.leadId + ':');
      if (fresh) Audio.play('claim');
      S.answered = a.phase !== 'question';
      const fb = a.feedback;
      const badge = a.whale ? '<span class="chip whale">Whale</span>' : a.steal ? '<span class="chip steal">Steal +$500</span>' : '';
      desk.innerHTML = `
        <div class="deal-head">
          <div><p class="eyebrow">${STAGES[a.stage]} · message ${a.stage + 1} of 3 ${badge}</p><h2>${esc(a.co)}</h2><p class="sub">${esc(a.who)} · ${esc(a.role)}</p></div>
          <div class="deal-val"><span class="hint">Deal value</span><b>${fmt(a.value)}</b></div>
        </div>
        <div class="stagebar">${STAGES.map((s, i) => `<span class="${i < a.stage + (fb ? 1 : 0) ? 'done' : i === a.stage ? 'now' : ''}">${s}</span>`).join('')}</div>
        <div class="buyer">${Art.char(a.char, { mood: fb ? 'happy' : 'neutral', title: a.who })}<div class="bubble"><small>${esc(a.who)} says</small>${esc(a.question)}</div></div>
        <div class="timer-row"><span>${fb ? 'Nice!' : 'Your reply'}</span><b id="tleft">${fb ? '' : (st.cfg.DECIDE_MS / 1000).toFixed(1) + 's'}</b></div>
        <div class="tbar" id="tbar"><i id="tfill" style="${fb ? 'transform:scaleX(0)' : ''}"></i></div>
        <div class="answers" id="answers">${a.options.map((o, i) => {
          let cls = 'ans';
          if (fb) cls += i === fb.correctIdx ? ' right' : ' faded';
          return `<button class="${cls}" type="button" data-i="${i}" ${fb ? 'disabled' : ''}><span class="k">${i + 1}</span><span>${esc(o)}</span></button>`;
        }).join('')}</div>
        ${fb ? `<div class="coach"><div class="ttl">Strong reply <span class="chip tone">${esc(fb.tone)}</span><span class="chip pts">+${fb.pts}${fb.fast ? ' fast' : ''}</span></div>${esc(fb.note)}</div>` : ''}`;
      if (fb) {
        Audio.play('good');
        const btn = desk.querySelector('.ans.right');
        if (btn) popAt(btn, '+' + fb.pts);
      }
      // On narrow screens the floor sits below the desk: bring the new question back into view.
      if (fresh && desk.getBoundingClientRect().top < 0) desk.scrollIntoView({ block: 'start' });
      return;
    }

    if (last && last.kind === 'fumble') {
      desk.innerHTML = `
        <div class="deal-head"><div><p class="eyebrow" style="color:var(--coral)">${last.timeout ? 'Out of time' : 'Fumbled'}</p><h2>${esc(last.who)} walked.</h2><p class="sub">${esc(last.co)} is back on the floor, worth 20% more. Anyone but you can steal it.</p></div></div>
        <div class="buyer" style="margin-top:14px">${Art.char(last.char, { mood: 'mad' })}<div class="bubble"><small>${esc(last.who)} said</small>${esc(last.question)}</div></div>
        <div class="answers" style="margin-top:14px">${last.options.map((o, i) => `<button class="ans ${i === last.correctIdx ? 'right' : i === last.chosen ? 'wrong' : 'faded'}" type="button" disabled><span class="k">${i + 1}</span><span>${esc(o)}</span></button>`).join('')}</div>
        <div class="coach bad"><div class="ttl">Coach <span class="chip tone">${esc(last.tone)}</span></div>${esc(last.note)}</div>
        <p class="cooldown" id="cooldown" style="margin-top:12px"></p>`;
      return;
    }

    if (last && last.kind === 'closed') {
      desk.innerHTML = `<div class="closed-won">
        <div class="stamp">${last.stolen ? 'Stolen &amp; won' : 'Closed won'}</div>
        ${Art.char(last.char, { mood: 'happy' })}
        <p>${esc(last.co)} signed for <b>${fmt(last.value)}</b>${last.whale ? '. You landed the whale!' : '.'}</p>
        <p class="big">+${last.pts.toLocaleString('en-US')} points</p>
        ${last.quota ? '<p class="chip pts">Quota hit · +2,500 bonus</p>' : ''}
        <p class="hint">Grab your next lead from the floor.</p></div>`;
      return;
    }

    desk.innerHTML = `<div class="desk-idle">
      ${Art.char(myChar, { color: myColor, mood: 'happy' })}
      <h2>Grab a lead!</h2>
      <p>Tap any card on the floor to claim it. Red cards are fumbles from other reps: steal them for a bonus.</p></div>`;
  }

  $('desk').addEventListener('click', e => {
    const b = e.target.closest('.ans[data-i]'); if (!b || b.disabled) return;
    choose(+b.dataset.i);
  });
  function choose(i) {
    const a = S.state && S.state.me && S.state.me.active;
    if (!a || a.phase !== 'question' || S.answered) return;
    S.answered = true;
    const btns = $('answers').querySelectorAll('.ans');
    btns.forEach((x, k) => { x.disabled = true; if (k === i) x.classList.add('picked'); });
    send({ type: 'answer', choice: i });
  }

  function renderFloor(st) {
    const box = $('floor');
    const seen = new Set();
    // Keep cards in the order they landed so nothing jumps under the player's finger.
    const order = st.floor.slice().sort((x, y) => +x.id.slice(1) - +y.id.slice(1));
    order.forEach((l, idx) => {
      seen.add(l.id);
      const mine = l.claimedBy === st.you, ownFumble = l.fumbledBy === st.you && !l.claimedBy;
      const claimer = l.claimedBy && st.players.find(p => p.id === l.claimedBy);
      const cls = 'lead' + (l.whale ? ' whale' : '') + (l.steal && !l.claimedBy ? ' steal' : '') + (l.claimedBy ? ' claimed' : '') + (ownFumble ? ' mine-fumble' : '');
      const badge = l.whale ? '<span class="badge chip whale">Whale</span>' : l.steal && !l.claimedBy ? `<span class="badge chip steal">Fumbled by ${esc(l.fumbledByName)}</span>` : '';
      const pips = '<span class="pips">' + [0, 1, 2].map(i => `<i class="${i < l.stage ? 'on' : ''}"></i>`).join('') + '</span>';
      const html = `${badge}${Art.char(l.char, { mood: l.steal && !l.claimedBy ? 'shock' : 'neutral' })}<span class="co">${esc(l.co)}</span><span class="who">${esc(l.who)} · ${esc(l.role)}</span><span class="foot"><span class="val">${fmt(l.value)}</span>${pips}</span>`;
      const by = mine ? 'You are pitching' : claimer ? claimer.name + ' is pitching' : ownFumble ? 'Your fumble' : '';
      const sig = cls + '|' + by + '|' + html;
      let el = S.cards.get(l.id);
      if (!el) { el = document.createElement('button'); el.type = 'button'; el.dataset.id = l.id; S.cards.set(l.id, el); }
      if (el._sig !== sig) {
        el._sig = sig; el.className = cls; el.innerHTML = html;
        el.disabled = !!l.claimedBy || ownFumble;
        if (by) el.dataset.by = by; else delete el.dataset.by;
        el.style.setProperty('--pc', claimer ? claimer.color : '');
        el.setAttribute('aria-label', `${l.co}, ${fmt(l.value)}${by ? ', ' + by : ''}`);
      }
      if (box.children[idx] !== el) box.insertBefore(el, box.children[idx] || null);
    });
    for (const [id, el] of S.cards) if (!seen.has(id)) { el.remove(); S.cards.delete(id); }
  }
  $('floor').addEventListener('click', e => {
    const b = e.target.closest('.lead'); if (!b || b.disabled) return;
    const st = S.state;
    if (st.me.active) return toast('Finish your current deal first.', 'bad');
    if (srvNow() < st.me.cooldownUntil) return toast('Shake it off… back on the floor in a second.', 'bad');
    send({ type: 'claim', id: b.dataset.id });
  });

  function renderStandings(st) {
    const list = st.players.slice().sort((a, b) => b.score - a.score);
    $('standings').innerHTML = list.map((p, i) => `<li class="${p.id === st.you ? 'me' : ''}" style="--pc:${p.color}">
      <span class="rk">${i + 1}</span>${Art.char(p.char, { color: p.color, mood: p.quotaHit ? 'happy' : 'neutral' })}
      <span class="nm">${esc(p.name)}${p.isBot ? ' <span class="tag">CPU</span>' : ''}${p.busy ? ' <span class="busy">● pitching</span>' : ''}
      <span class="mini"><i style="width:${Math.min(100, p.revenue / st.cfg.QUOTA * 100)}%"></i></span></span>
      <span class="sc">${p.score.toLocaleString('en-US')}</span></li>`).join('');
  }

  function renderFeed(st) {
    $('feed').innerHTML = st.feed.slice().reverse().slice(0, 8).map(f => `<li><time>${mmss(st.cfg.ROUND_MS - f.t)}</time><span class="${esc(f.kind)}">${esc(f.text)}</span></li>`).join('');
  }

  function processFeed(st) {
    for (const f of st.feed) {
      if (f.seq <= S.lastSeq) continue;
      S.lastSeq = f.seq;
      const mine = f.pid === st.you;
      if (f.kind === 'whale') { Audio.play('whale'); toast(f.text, 'whale'); }
      else if (f.kind === 'steal' && !mine) Audio.play('steal');
      else if ((f.kind === 'close' || f.kind === 'whale-close') && !mine) Audio.play('otherClose');
      else if (f.kind === 'quota' && !mine) toast(f.text);
      else if (f.kind === 'info' && /Time!/.test(f.text)) Audio.play('end');
    }
  }

  /* ---------- results ---------- */

  function renderResults(st) {
    const ranked = (st.results || []).map(id => st.players.find(p => p.id === id)).filter(Boolean);
    const extra = st.players.filter(p => !ranked.includes(p));
    const all = ranked.concat(extra);
    const winner = all[0];
    const myRank = all.findIndex(p => p.id === st.you) + 1;
    $('resultTitle').textContent = winner ? (winner.id === st.you ? 'You top the floor!' : winner.name + ' tops the floor') : 'Round over';
    $('resultSub').textContent = myRank ? `You finished #${myRank} of ${all.length}.` : '';
    $('podium').innerHTML = all.slice(0, 3).map((p, i) => `<div class="pod p${i + 1}" style="--pc:${p.color}">
      ${Art.char(p.char, { color: p.color, mood: i === 0 ? 'happy' : 'neutral' })}<span class="nm">${esc(p.name)}</span><span class="sc">${p.score.toLocaleString('en-US')} pts</span><div class="block">${i + 1}</div></div>`).join('');
    const awards = [];
    const most = (key, min) => { const top = all.slice().sort((a, b) => b[key] - a[key])[0]; return top && top[key] >= (min || 1) ? top : null; };
    const thief = most('steals'); if (thief) awards.push(['Top thief', `${thief.name} · ${thief.steals} steal${thief.steals === 1 ? '' : 's'}`]);
    const streak = most('bestStreak', 3); if (streak) awards.push(['Hot streak', `${streak.name} · ${streak.bestStreak} in a row`]);
    const first = st.firstQuota && st.players.find(p => p.id === st.firstQuota); if (first) awards.push(['First to quota', first.name]);
    const fumbler = most('fumbles', 3); if (fumbler) awards.push(['Butterfingers', `${fumbler.name} · ${fumbler.fumbles} fumbles`]);
    $('awards').innerHTML = awards.map(a => `<div class="award"><b>${a[0]}</b>${esc(a[1])}</div>`).join('');
    $('resultRows').innerHTML = all.map((p, i) => `<tr class="${p.id === st.you ? 'me' : ''}"><td>${i + 1}</td><td>${esc(p.name)}${p.isBot ? ' <span class="tag">CPU</span>' : ''}</td>
      <td>${p.score.toLocaleString('en-US')}</td><td>${fmt(p.revenue)}</td><td>${p.deals}</td><td>${p.steals}</td><td>${p.asked ? Math.round(p.right / p.asked * 100) : 0}%</td></tr>`).join('');
    const host = st.hostId === st.you;
    $('againBtn').hidden = $('backRoomBtn').hidden = !host;
    $('resultsWait').hidden = host;
    Audio.setHype(false);
  }
  $('againBtn').onclick = () => { Audio.unlock(); send({ type: 'start' }); };
  $('backRoomBtn').onclick = () => send({ type: 'lobby' });

  /* ---------- animation loop: clock, answer timer, cooldown ---------- */

  function frame() {
    const st = S.state;
    if (st && st.phase === 'playing' && S.screen === 'play') {
      const left = st.endsAt - srvNow();
      $('clock').textContent = mmss(left);
      $('clock').classList.toggle('hot', left <= 30000);
      if (left <= 30000 && !S.hype) { S.hype = true; Audio.setHype(true); }
      const sec = Math.ceil(left / 1000);
      if (sec <= 10 && sec > 0 && sec !== S.lastTickSec) { S.lastTickSec = sec; Audio.play('tick'); }
      const a = st.me.active;
      if (a && a.phase === 'question') {
        const rem = Math.max(0, a.deadline - srvNow());
        const fill = $('tfill'), tl = $('tleft'), bar = $('tbar');
        if (fill) fill.style.transform = `scaleX(${rem / st.cfg.DECIDE_MS})`;
        if (tl) tl.textContent = (rem / 1000).toFixed(1) + 's';
        if (bar) bar.classList.toggle('hot', rem < 5000);
      }
      const cd = $('cooldown');
      if (cd) { const r = st.me.cooldownUntil - srvNow(); cd.textContent = r > 0 ? 'Back on the floor in ' + Math.ceil(r / 1000) + 's…' : 'Back in action. Grab a lead!'; }
    } else if (S.hype) { S.hype = false; Audio.setHype(false); }
    requestAnimationFrame(frame);
  }

  document.addEventListener('keydown', e => {
    if (S.screen !== 'play' || e.target.tagName === 'INPUT') return;
    if (/^[1-4]$/.test(e.key)) choose(+e.key - 1);
  });

  /* ---------- sound toggles ---------- */

  function syncToggles() {
    $('musicBtn').setAttribute('aria-pressed', Audio.musicOn); $('musicBtn').textContent = Audio.musicOn ? '♪ MUSIC' : '♪ OFF';
    $('sfxBtn').setAttribute('aria-pressed', Audio.sfxOn); $('sfxBtn').textContent = Audio.sfxOn ? 'SFX' : 'SFX OFF';
  }
  $('musicBtn').onclick = () => { Audio.setMusic(!Audio.musicOn); syncToggles(); };
  $('sfxBtn').onclick = () => { Audio.unlock(); Audio.setSfx(!Audio.sfxOn); syncToggles(); };
  document.addEventListener('pointerdown', () => Audio.unlock(), { once: true });

  /* ---------- little effects ---------- */

  let toastTimer = 0;
  function toast(text, kind) {
    const t = $('toast');
    t.textContent = text; t.className = 'toast' + (kind ? ' ' + kind : ''); t.hidden = false;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 2800);
  }
  function popAt(el, text) {
    const r = el.getBoundingClientRect();
    const p = document.createElement('div'); p.className = 'pop'; p.textContent = text;
    p.style.left = Math.min(window.innerWidth - 110, r.left + r.width * 0.55) + 'px'; p.style.top = r.top + 'px';
    document.body.appendChild(p); setTimeout(() => p.remove(), 1000);
  }
  function confetti() {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const r = $('desk').getBoundingClientRect(), colors = ['#ffd23f', '#3ee0a1', '#ff8fb1', '#7fb2ff', '#ff9f43'];
    for (let i = 0; i < 36; i++) {
      const c = document.createElement('i'); c.className = 'confetti';
      c.style.left = (r.left + r.width / 2 + (Math.random() - 0.5) * 120) + 'px'; c.style.top = (r.top + 80) + 'px';
      c.style.background = colors[i % colors.length];
      c.style.setProperty('--dx', (Math.random() - 0.5) * 420 + 'px'); c.style.setProperty('--rot', Math.random() * 720 + 'deg');
      document.body.appendChild(c); setTimeout(() => c.remove(), 1300);
    }
  }

  buildHome();
  syncToggles();
  connectOnline();
  requestAnimationFrame(frame);
})();
