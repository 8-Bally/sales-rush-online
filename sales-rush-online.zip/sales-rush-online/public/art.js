// Sales Rush characters and logo, drawn as inline SVG (no image files needed).
(function (root) {
  'use strict';
  const INK = '#1d1a2e';
  const BASE = { mug: '#7fb2ff', cat: '#ff9f43', bot: '#c9d0ff', cactus: '#3ee0a1', toast: '#f2b866', owl: '#c4a1ff' };
  const NAMES = { mug: 'Mug', cat: 'Whiskers', bot: 'Botley', cactus: 'Spike', toast: 'Toasty', owl: 'Hoot' };

  // mood: 'happy' | 'neutral' | 'mad' | 'shock'
  // beak: the owl has a beak and eye rings, so skip the mouth and cheeks
  function face(mood, cx, cy, ink, wide, o) {
    const beak = o && o.beak;
    const dx = wide ? 14 + (beak ? 1 : 0) : 12, ex = cx - dx, ex2 = cx + dx, my = cy + 15;
    let eyes;
    if (mood === 'happy') eyes = `<path d="M${ex - 5} ${cy + 1}q5 -7 10 0M${ex2 - 5} ${cy + 1}q5 -7 10 0" stroke="${ink}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`;
    else eyes = `<circle cx="${ex}" cy="${cy}" r="${mood === 'shock' ? 5.5 : 4.5}" fill="${ink}"/><circle cx="${ex2}" cy="${cy}" r="${mood === 'shock' ? 5.5 : 4.5}" fill="${ink}"/>` +
      `<circle cx="${ex + 1.5}" cy="${cy - 1.5}" r="1.5" fill="#fff"/><circle cx="${ex2 + 1.5}" cy="${cy - 1.5}" r="1.5" fill="#fff"/>`;
    const brows = mood === 'mad'
      ? `<path d="M${ex - 6} ${cy - 11}l11 4M${ex2 + 6} ${cy - 11}l-11 4" stroke="${ink}" stroke-width="3.5" stroke-linecap="round"/>` : '';
    const mouth = {
      happy: `<path d="M${cx - 8} ${my - 2}q8 10 16 0" stroke="${ink}" stroke-width="3.5" fill="#ff6b7d" stroke-linejoin="round"/>`,
      neutral: `<path d="M${cx - 5} ${my}q5 4 10 0" stroke="${ink}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
      mad: `<path d="M${cx - 7} ${my + 3}q7 -7 14 0" stroke="${ink}" stroke-width="3.5" fill="none" stroke-linecap="round"/>`,
      shock: `<ellipse cx="${cx}" cy="${my + 1}" rx="4.5" ry="6" fill="${ink}"/>`
    }[mood] || '';
    const blush = `<ellipse cx="${ex - 7}" cy="${cy + 10}" rx="5" ry="3" fill="#ff6b7d" opacity=".45"/><ellipse cx="${ex2 + 7}" cy="${cy + 10}" rx="5" ry="3" fill="#ff6b7d" opacity=".45"/>`;
    return beak ? eyes + brows : blush + eyes + brows + mouth;
  }

  /* ---------- people: buyers and player reps ---------- */
  // back: hair drawn behind the head; front: hairline; outfit: what they wear to work.
  const PEOPLE = {
    // buyers
    maya:   { skin: '#c98d62', hair: '#2a1a12', back: 'ponytail', front: 'side', outfit: 'zip', top: '#20a39e', shirt: '#ffffff' },
    jordan: { skin: '#6b4129', hair: '#17110e', front: 'fade', outfit: 'suit', top: '#2c3a78', shirt: '#e9eefc', tie: '#ff6b5e' },
    chris:  { skin: '#f2c7a5', hair: '#8a4a22', front: 'swoop', beard: true, outfit: 'quarter', top: '#4b8b5f', shirt: '#ffffff' },
    alex:   { skin: '#e6b98f', hair: '#141414', front: 'short', outfit: 'polo', top: '#ff9f43', shirt: '#ffd9b0' },
    dana:   { skin: '#b97a4f', hair: '#3b2317', back: 'long', front: 'side', outfit: 'blouse', top: '#59627a', shirt: '#f7e6d6', earrings: true, necklace: true },
    priya:  { skin: '#9b6441', hair: '#141010', back: 'bun', front: 'side', outfit: 'apron', top: '#c0504d', shirt: '#f3e6c4', earrings: true },
    sam:    { skin: '#4b2d1e', hair: '#141010', front: 'fade', glasses: true, outfit: 'coat', top: '#f4f6fb', shirt: '#9cc3ff', tie: '#2c3a78' },
    morgan: { skin: '#f5d4b8', hair: '#e2b45a', back: 'bob', front: 'side', outfit: 'blouse', top: '#d6455d', shirt: '#ffffff', earrings: true },
    theo:   { skin: '#7b4a2f', hair: '#1d1410', back: 'afro', front: 'afro', outfit: 'hoodie', top: '#2b2f45', shirt: '#ffd23f' },
    rosa:   { skin: '#d49b6b', hair: '#cfd0d8', back: 'bun', front: 'side', glasses: true, outfit: 'cardigan', top: '#8e6bd1', shirt: '#ffffff' },
    vic:    { skin: '#f0cbae', hair: '#a6a7b2', front: 'bald', beard: true, outfit: 'suit', top: '#1f2233', shirt: '#ffffff', tie: '#ffd23f' },
    lena:   { skin: '#efc9a2', hair: '#141414', back: 'bob', front: 'bangs', outfit: 'open', top: '#7a5cd6', shirt: '#ffffff', earrings: true },
    // player reps
    amara:  { skin: '#8a5839', hijab: '#20a39e', outfit: 'blouse', top: '#2c3a78', shirt: '#f7e6d6' },
    marcus: { skin: '#5a3523', hair: '#1a120e', back: 'locs', front: 'short', beard: true, outfit: 'suit', top: '#3a3f58', shirt: '#ffffff', tie: '#3ee0a1' },
    mei:    { skin: '#f0cfa8', hair: '#1b1b1b', back: 'bob', front: 'bangs', glasses: true, outfit: 'open', top: '#ff8fb1', shirt: '#ffffff' },
    diego:  { skin: '#c58b5c', hair: '#2b1d14', front: 'short', mustache: true, outfit: 'vest', top: '#4b5bd6', shirt: '#ffffff', tie: '#ff6b5e' },
    grace:  { skin: '#7a4b33', hair: '#dcdce4', back: 'curly', front: 'curly', glasses: true, outfit: 'cardigan', top: '#ff9f43', shirt: '#ffffff', earrings: true },
    riley:  { skin: '#f7d6c1', hair: '#c4572b', back: 'long', front: 'side', freckles: true, outfit: 'blouse', top: '#3ee0a1', shirt: '#ffffff' }
  };
  const REP_PEOPLE = ['amara', 'marcus', 'mei', 'diego', 'grace', 'riley'];

  function person(p, opts) {
    const top = opts.color || p.top, mood = opts.mood || 'neutral';
    const ln = w => `stroke="${INK}" stroke-width="${w || 3.5}" stroke-linejoin="round" stroke-linecap="round"`;
    const shade = `fill="${INK}" opacity=".16"`;
    const hairFill = `fill="${p.hair}" ${ln()}`;
    let out = '';

    const backs = {
      long: `<path d="M31 50C28 20 92 20 89 50L93 96Q60 104 27 96Z" ${hairFill}/>`,
      bob: `<path d="M31 48C28 20 92 20 89 48L91 78Q60 86 29 78Z" ${hairFill}/>`,
      afro: `<ellipse cx="60" cy="42" rx="37" ry="31" ${hairFill}/>`,
      curly: [[38, 40, 13], [50, 28, 13], [66, 26, 13], [80, 36, 13], [87, 54, 10], [33, 56, 10]].map(c => `<circle cx="${c[0]}" cy="${c[1]}" r="${c[2]}" ${hairFill}/>`).join(''),
      locs: `<path d="M32 46C30 20 90 20 88 46L92 98H80L78 64H42L40 98H28Z" ${hairFill}/><path d="M34 70v24M86 70v24" stroke="${INK}" stroke-width="2" opacity=".5"/>`,
      ponytail: `<path d="M82 34C104 38 106 70 94 84C96 64 92 52 80 46Z" ${hairFill}/>`,
      bun: `<circle cx="60" cy="22" r="12" ${hairFill}/>`
    };
    if (!p.hijab && p.back) out += backs[p.back] || '';

    // shoulders and outfit
    out += `<path d="M12 124C12 100 28 89 60 89C92 89 108 100 108 124Z" fill="${p.outfit === 'vest' ? p.shirt : top}" ${ln()}/>`;
    if (!p.hijab) out += `<rect x="53" y="70" width="14" height="22" fill="${p.skin}" ${ln(3)}/>`;
    const vneck = `<path d="M49 89L60 108L71 89Z" fill="${p.shirt}" ${ln(2.5)}/>`;
    const tie = `<path d="M57.5 94h5l2 16-4.5 6-4.5-6z" fill="${p.tie || '#ff6b5e'}" ${ln(2)}/>`;
    const lapels = `<path d="M49 89L58 116L45 104L43 92ZM71 89L62 116L75 104L77 92Z" ${shade}/>`;
    const round = `<path d="M48 89Q60 100 72 89Z" fill="${p.shirt}" ${ln(2.5)}/>`;
    switch (p.outfit) {
      case 'suit': out += vneck + tie + lapels; break;
      case 'open': out += vneck + lapels; break;
      case 'blouse': out += round + lapels + (p.necklace ? `<path d="M51 94q9 9 18 0" stroke="#ffd23f" stroke-width="2.5" fill="none"/>` : ''); break;
      case 'coat': out += vneck + tie + `<path d="M49 89L57 118M71 89L63 118" ${ln(2.5)}/><path d="M47 94q-7 14 3 20M73 94q7 14 -3 20" stroke="#4a4f6b" stroke-width="3" fill="none"/><circle cx="50" cy="115" r="3.5" fill="#9aa3c7" ${ln(2)}/>`; break;
      case 'apron': out += round + `<rect x="45" y="99" width="30" height="26" rx="4" fill="#fff4dc" ${ln(2.5)}/><path d="M47 99L50 90M73 99L70 90" ${ln(2.5)}/>`; break;
      case 'cardigan': out += vneck + `<path d="M60 108V124" ${ln(2)}/><circle cx="56" cy="113" r="1.8" fill="${INK}"/><circle cx="56" cy="120" r="1.8" fill="${INK}"/>`; break;
      case 'zip': out += `<path d="M48 86h24v7H48z" fill="${top}" ${ln(2.5)}/><path d="M60 93V124" ${ln(2)}/>`; break;
      case 'quarter': out += `<path d="M47 86h26v7H47z" fill="${top}" ${ln(2.5)}/><path d="M60 86V106" ${ln(2)}/><circle cx="60" cy="106" r="2" fill="#c9cde0"/>`; break;
      case 'polo': out += `<path d="M48 88l12 8-13 5zM72 88l-12 8 13 5z" fill="${p.shirt}" ${ln(2.5)}/><path d="M60 96v10" ${ln(2)}/>`; break;
      case 'hoodie': out += vneck + `<path d="M40 93q20 -14 40 0" stroke="${INK}" stroke-width="3" fill="none" opacity=".5"/><path d="M53 100v12M67 100v12" stroke="#f6f4ff" stroke-width="2.5" stroke-linecap="round"/>`; break;
      case 'vest': out += `<path d="M30 124L46 91L60 110L74 91L90 124Z" fill="${top}" ${ln(2.5)}/>` + tie; break;
    }

    if (p.hijab) {
      out += `<path d="M30 58C26 16 94 16 90 58C92 76 96 92 102 106Q60 118 18 106C24 92 28 76 30 58Z" fill="${p.hijab}" ${ln()}/>`;
      out += `<ellipse cx="60" cy="56" rx="21" ry="24" fill="${p.skin}" ${ln(3)}/>`;
      out += `<path d="M38 50C40 30 80 30 82 50" stroke="${INK}" stroke-width="2" fill="none" opacity=".35"/>`;
    } else {
      out += `<circle cx="35" cy="56" r="6" fill="${p.skin}" ${ln(3)}/><circle cx="85" cy="56" r="6" fill="${p.skin}" ${ln(3)}/>`;
      out += `<ellipse cx="60" cy="53" rx="25" ry="27" fill="${p.skin}" ${ln()}/>`;
      const fronts = {
        short: `<path d="M35 48C33 26 48 20 62 21C78 22 88 32 85 48C80 38 70 34 58 34C48 34 40 40 35 48Z" ${hairFill}/>`,
        fade: `<path d="M36 42C37 27 48 23 60 23C73 23 83 27 84 42C75 34 45 34 36 42Z" ${hairFill}/>`,
        swoop: `<path d="M34 50C30 26 52 16 72 22C84 26 90 36 86 50C82 40 74 34 66 32C58 40 46 42 34 50Z" ${hairFill}/>`,
        side: `<path d="M35 47C35 25 85 24 86 47C78 34 66 31 58 38C52 33 42 36 35 47Z" ${hairFill}/>`,
        bangs: `<path d="M35 47C34 23 86 23 85 47Q60 37 35 47Z" ${hairFill}/>`,
        afro: `<path d="M36 44C38 29 50 26 60 26C72 26 82 29 84 44C74 37 46 37 36 44Z" ${hairFill}/>`,
        curly: [[44, 32, 8], [57, 28, 8], [71, 30, 8], [81, 40, 6]].map(c => `<circle cx="${c[0]}" cy="${c[1]}" r="${c[2]}" ${hairFill}/>`).join(''),
        bald: `<path d="M35 60C32 50 34 42 39 39L41 58ZM85 60C88 50 86 42 81 39L79 58Z" fill="${p.hair}" ${ln(2.5)}/><path d="M50 32q8 -4 14 -1" stroke="#fff" stroke-width="3" opacity=".5" fill="none"/>`
      };
      out += fronts[p.front] || '';
      if (p.beard) out += `<path d="M36 57C36 86 84 86 84 57C80 71 72 77 60 77C48 77 40 71 36 57Z" fill="${p.hair}" ${ln(2.5)}/>`;
      if (p.beard || p.mustache) out += `<path d="M49 66q11 -6 22 0q-11 4 -22 0Z" fill="${p.hair}" ${ln(2)}/>`;
    }
    if (p.freckles) out += [[42, 63], [46, 66], [74, 66], [78, 63]].map(c => `<circle cx="${c[0]}" cy="${c[1]}" r="1.3" fill="#a0522d"/>`).join('');
    out += face(mood, 60, 54, INK, false);
    if (p.glasses) out += `<rect x="39" y="46" width="18" height="15" rx="5" fill="#fff" fill-opacity=".18" ${ln(2.5)}/><rect x="63" y="46" width="18" height="15" rx="5" fill="#fff" fill-opacity=".18" ${ln(2.5)}/><path d="M57 52h6" ${ln(2.5)}/>`;
    if (p.earrings && !p.hijab) out += `<circle cx="35" cy="65" r="3" fill="#ffd23f" ${ln(1.5)}/><circle cx="85" cy="65" r="3" fill="#ffd23f" ${ln(1.5)}/>`;
    return out;
  }

  function char(kind, opts) {
    opts = opts || {};
    const c = opts.color || BASE[kind] || BASE.mug, mood = opts.mood || 'neutral';
    const line = `stroke="${INK}" stroke-width="3.5" stroke-linejoin="round"`;
    let body = '', f = '';
    if (PEOPLE[kind]) body = person(PEOPLE[kind], opts);
    else switch (kind) {
      case 'cat':
        body = `<path d="M26 52L30 16L52 36ZM94 52L90 16L68 36Z" fill="${c}" ${line}/><path d="M33 26l5 14M87 26l-5 14" stroke="#ff8fb1" stroke-width="4" stroke-linecap="round"/>` +
          `<ellipse cx="60" cy="68" rx="38" ry="34" fill="${c}" ${line}/>` +
          `<path d="M20 74h14M18 82l15 -3M100 74h-14M102 82l-15 -3" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>` +
          `<path d="M57 77l3 3 3 -3z" fill="${INK}"/>`;
        f = face(mood, 60, 63, INK, true); break;
      case 'bot':
        body = `<path d="M60 14v14" ${line}/><circle cx="60" cy="12" r="6" fill="#ffd23f" ${line}/>` +
          `<rect x="22" y="28" width="76" height="72" rx="18" fill="${c}" ${line}/><rect x="13" y="54" width="9" height="20" rx="4" fill="${c}" ${line}/><rect x="98" y="54" width="9" height="20" rx="4" fill="${c}" ${line}/>` +
          `<rect x="31" y="39" width="58" height="48" rx="11" fill="#141b4d"/>`;
        f = face(mood, 60, 58, '#7dffcb', false).replace(/fill="#ff6b7d" opacity=".45"/g, 'fill="#7dffcb" opacity=".25"'); break;
      case 'cactus':
        body = `<path d="M36 80h-8a8 8 0 0 1 -8 -8v-18a7 7 0 0 1 14 0v12h6M84 66h8a8 8 0 0 0 8 -8v-14a7 7 0 0 0 -14 0v8h-6" fill="${c}" ${line}/>` +
          `<rect x="36" y="20" width="48" height="84" rx="24" fill="${c}" ${line}/>` +
          `<path d="M46 34l-4 -3M74 34l4 -3M46 92l-4 3M74 92l4 3M60 26v-5" stroke="${INK}" stroke-width="2.5" stroke-linecap="round"/>` +
          `<circle cx="60" cy="18" r="6" fill="#ff8fb1" ${line}/>` +
          `<path d="M30 100h60l-7 18h-46z" fill="#ff6b5e" ${line}/>`;
        f = face(mood, 60, 56, INK, false); break;
      case 'toast':
        body = `<path d="M24 58C14 28 44 18 60 28C76 18 106 28 96 58L94 104Q94 112 86 112H34Q26 112 26 104Z" fill="#d98b3a" ${line}/>` +
          `<path d="M33 60C26 38 48 31 60 39C72 31 94 38 87 60L85 100Q85 104 81 104H39Q35 104 35 100Z" fill="${c}"/>`;
        f = face(mood, 60, 66, INK, false); break;
      case 'owl':
        body = `<path d="M30 40L26 14L48 30ZM90 40L94 14L72 30Z" fill="${c}" ${line}/>` +
          `<ellipse cx="60" cy="68" rx="38" ry="42" fill="${c}" ${line}/><ellipse cx="60" cy="86" rx="22" ry="20" fill="#fff" opacity=".55"/>` +
          `<circle cx="45" cy="56" r="14" fill="#fff" ${line}/><circle cx="75" cy="56" r="14" fill="#fff" ${line}/>` +
          `<path d="M55 68l5 8 5 -8z" fill="#ffb02e" ${line}/>`;
        f = face(mood, 60, 56, INK, true, { beak: true }); break;
      default: // mug
        body = `<path d="M90 50h6a14 14 0 0 1 0 28h-6" fill="none" stroke="${INK}" stroke-width="10"/><path d="M90 50h6a14 14 0 0 1 0 28h-6" fill="none" stroke="${c}" stroke-width="4"/>` +
          `<path d="M24 36h68v58a16 16 0 0 1 -16 16h-36a16 16 0 0 1 -16 -16z" fill="${c}" ${line}/><path d="M24 44h68" stroke="${INK}" stroke-width="3" opacity=".25"/>` +
          `<path d="M44 26q-5 -7 0 -14M60 24q-5 -7 0 -14M76 26q-5 -7 0 -14" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" opacity=".65"/>`;
        f = face(mood, 58, 68, INK, false);
    }
    const label = opts.title ? `<title>${String(opts.title).replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[ch]))}</title>` : '';
    return `<svg class="char char-${kind}" viewBox="0 0 120 124" role="img" aria-hidden="${opts.title ? 'false' : 'true'}" xmlns="http://www.w3.org/2000/svg">${label}${body}${f}</svg>`;
  }

  // Stopwatch with a rising sales line: the Sales Rush mark.
  function logo(size) {
    size = size || 40;
    return `<svg width="${size}" height="${size}" viewBox="0 0 64 64" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">` +
      `<rect x="2" y="2" width="60" height="60" rx="16" fill="#ffd23f"/>` +
      `<rect x="27" y="7" width="10" height="7" rx="2.5" fill="#141b4d"/><path d="M46 14l5 -5" stroke="#141b4d" stroke-width="4.5" stroke-linecap="round"/>` +
      `<circle cx="32" cy="36" r="19" fill="#141b4d"/>` +
      `<path d="M20 44l8 -8 6 5 10 -12" stroke="#ffd23f" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>` +
      `<path d="M38 28h7v7" stroke="#ffd23f" stroke-width="4.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }

  REP_PEOPLE.forEach(k => { NAMES[k] = k[0].toUpperCase() + k.slice(1); });
  // KINDS: mascots only (background art). REPS: everything a player can pick.
  root.SRArt = { char, logo, BASE, NAMES, KINDS: Object.keys(BASE), PEOPLE: Object.keys(PEOPLE), REPS: REP_PEOPLE.concat(Object.keys(BASE)) };
})(typeof self !== 'undefined' ? self : this);
