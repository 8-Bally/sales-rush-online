# Sales Rush

A real-time multiplayer sales race for 2–8 players. Everyone works the same sales floor: claim leads before your friends do, win the buyer over in three replies, and steal every deal they fumble.

## Run it

Needs Node.js 18 or newer.

```bash
npm install
npm start
```

Open http://localhost:3000. To play together, everyone opens the same address on their own device: one player creates a room and shares the code or invite link.

## How a round works

- **3:00 round, $25,000 quota.** Leads land on a shared floor. Tap one first and it's yours.
- **Three buyer messages per deal.** You have 24 seconds to pick the best reply each time.
- **Fumbles become steals.** A weak reply or a timeout drops the deal back on the floor, worth 20% more, keeping its progress. Anyone except the player who fumbled it can swoop in.
- **Whales.** At 2:00 and 1:00 left, a big account ($13,500–$15,000) hits the floor for everyone to race for.
- **CPU reps.** The host can add computer reps to fill a room. Practice mode is you plus 3 CPU reps, with no server needed.

| Event | Points |
|---|---|
| Strong reply | +100 × streak (up to ×4) |
| Fast reply (over half the time left) | +250 |
| Closed deal | +500 + 18% of deal value |
| Closing someone else's fumble | +500 steal bonus |
| Hitting the $25K quota | +2,500 (once) |

## Files

| File | What it does |
|---|---|
| `server.js` | Node server: serves `public/` and runs rooms over WebSockets (`ws`). |
| `public/engine.js` | All game rules and room handling. Runs on the server and in the browser (practice mode). |
| `public/content.js` | The buyer book: 10 accounts and 2 whales, 3 questions each, 4 replies per question. `a[0]` is always the best reply; the engine shuffles before players see it. |
| `public/game.js` | The browser client: screens, rendering, input, sound cues. |
| `public/art.js` | The logo and all characters as inline SVG: 12 buyers in work clothes, 6 people reps players can pick (Amara, Marcus, Mei, Diego, Grace, Riley), and 6 mascots (Mug, Whiskers, Botley, Spike, Toasty, Hoot). |
| `public/audio.js` | Original chiptune loop and sound effects, synthesized with Web Audio. It speeds up in the last 30 seconds. |
| `public/style.css`, `public/index.html` | Look and layout. |
| `public/cover.html` | A 1200×630 cover image page. Open it and screenshot the card. |

## Settings

- `window.SR_SERVER_URL` in `public/index.html`: leave empty when the game server serves the page. Set it to a `wss://…` address if the WebSocket server lives somewhere else. Set it to `'none'` for practice-only.
- Add `?local` to the page URL to run rooms inside one browser tab (CPU reps only). Useful for testing without a server.
- Round length, decision window, quota and bonuses are in `CFG` at the top of `public/engine.js`.

## Editing the questions

Each question in `public/content.js` has a buyer line `q`, four replies `a` (best one first), a coaching `note`, and a `tone` label shown after a strong reply. Keep the best reply's length varied: sometimes shortest, sometimes longest, so players have to read.

A question slot can also be an array of alternatives, and each new lead picks one at random. That's how the occasional funny moment shows up (the buyer who asks you out for drinks, the robocall test, Biscuit the decision-making cat) without happening every round.
