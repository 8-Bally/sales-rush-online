# Handing Sales Rush to ChatGPT for hosting

Upload the whole `sales-rush-online` folder, then paste the prompt below.

## Prompt to paste

> I'm uploading a finished multiplayer browser game called Sales Rush. Please host it on my site without changing the gameplay, art, or text.
>
> How it's built:
> - `server.js` is a small Node.js server (Node 18+, one dependency: `ws`). It serves the `public/` folder and runs game rooms over WebSockets on the same port. Start command: `npm install && npm start`. It reads the port from `PORT`.
> - All game rules live in `public/engine.js`. It exports `createHub()`, which handles every room. The server only forwards JSON messages between each browser and the hub, and calls `hub.tick()` every 100 ms.
> - The browser connects to a WebSocket at the page's own address by default. If the WebSocket server must live at a different address, set `window.SR_SERVER_URL` in `public/index.html` to that `wss://` URL.
>
> If your hosting can run this Node server with WebSockets, deploy it as is.
>
> If your hosting uses a different real-time system, keep `public/` and `engine.js` unchanged and replace only the transport: on the server side, call `hub.connect(sendFn)` for each player connection, pass each incoming JSON message to `hub.receive(conn, msg)`, call `hub.disconnect(conn)` when they leave, and call `hub.tick()` every 100 ms. In `public/game.js`, `connectOnline()` is the only function that talks to the network: swap its WebSocket for your platform's channel, keeping the same JSON messages.
>
> Please check after deploying: two browsers can create and join the same room by code, both see the same leads on the floor, a fumbled deal shows up as a red "steal" card for the other player, and Practice mode works.

## Message protocol (browser ↔ server, JSON)

Browser sends:

| type | fields | when |
|---|---|---|
| `rooms` | | Ask for open rooms (home screen polls every 4s) |
| `create` | `name`, `char`, `token`, `practice?` | Create a room (practice adds 3 CPU reps and starts) |
| `join` | `code`, `name`, `char`, `token` | Join by code; the same `token` rejoins your seat after a refresh |
| `addBot` / `removeBot` | `id` for remove | Host only, before the round |
| `start` | | Host only; also used for "Play again" |
| `lobby` | | Host only; back to the waiting room after results |
| `claim` | `id` (lead id) | Claim a lead on the floor |
| `answer` | `choice` (0–3) | Answer the current buyer message |
| `leave` | | Leave the room |

Server sends:

| type | fields |
|---|---|
| `joined` | `code`, `you` (player id) |
| `state` | `state`: the full view for this player (each player gets their own; correct answers are never sent before they answer) |
| `rooms` | `rooms`: `[{ code, host, players }]` |
| `error` | `message`: plain-language reason to show the player |

## Contest entry

- **Title:** Sales Rush
- **Cover image:** open `public/cover.html` in a browser and screenshot the 1200×630 card.
- **Description:**
  Sales Rush is a real-time sales race for 2–8 players. Everyone works the same sales floor: tap a lead before your friends do, then win the buyer over in three replies, each with a 24-second clock. Pick a weak reply and the buyer walks. The deal drops back on the floor worth 20% more, and anyone can swoop in to steal it. Whale accounts drop mid-round for everyone to race for. Every reply teaches a real sales skill, from handling price objections to booking the next step, and the coaching note after each answer explains why the best reply works. It has a diverse cast of original cartoon buyers and reps, a few unhinged buyers to keep you on your toes, chiptune music made in code, and a practice mode against CPU reps.
- **Link:** the URL ChatGPT gives you after hosting.
